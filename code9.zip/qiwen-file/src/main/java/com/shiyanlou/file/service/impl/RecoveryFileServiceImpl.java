package com.shiyanlou.file.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.shiyanlou.file.mapper.RecoveryFileMapper;
import com.shiyanlou.file.model.RecoveryFile;
import com.shiyanlou.file.service.RecoveryFileService;

public class RecoveryFileServiceImpl extends ServiceImpl<RecoveryFileMapper, RecoveryFile>
        implements RecoveryFileService {
    
}