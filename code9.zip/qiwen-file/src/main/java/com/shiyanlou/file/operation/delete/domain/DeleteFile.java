package com.shiyanlou.file.operation.delete.domain;

import lombok.Data;

@Data
public class DeleteFile {
    private String fileUrl;
    private String timeStampName;
}