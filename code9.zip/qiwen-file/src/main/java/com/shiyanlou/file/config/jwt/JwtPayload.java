package com.shiyanlou.file.config.jwt;

import lombok.Data;

@Data
public class JwtPayload {
    private RegisterdClaims registerdClaims;
}
