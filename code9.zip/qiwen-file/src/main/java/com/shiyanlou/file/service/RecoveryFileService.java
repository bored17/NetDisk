package com.shiyanlou.file.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.shiyanlou.file.model.RecoveryFile;

public interface RecoveryFileService extends IService<RecoveryFile> {
    
}