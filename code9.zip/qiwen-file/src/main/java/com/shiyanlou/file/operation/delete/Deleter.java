package com.shiyanlou.file.operation.delete;

import com.shiyanlou.file.operation.delete.domain.DeleteFile;

public abstract class Deleter {
    public abstract void delete(DeleteFile deleteFile);
}
