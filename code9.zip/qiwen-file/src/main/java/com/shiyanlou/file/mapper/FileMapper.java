package com.shiyanlou.file.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shiyanlou.file.model.File;

public interface FileMapper extends BaseMapper<File> {

}