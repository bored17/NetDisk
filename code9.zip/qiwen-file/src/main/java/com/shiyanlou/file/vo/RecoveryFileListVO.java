package com.shiyanlou.file.vo;

public class RecoveryFileListVO {
    
}
